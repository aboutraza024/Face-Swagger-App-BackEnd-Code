import async_timeout
from fastapi import FastAPI, Depends
from fastapi import Request, HTTPException
import uvicorn
from sqlalchemy.orm import Session
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from routes.route_categories import router as categories
from routes.route_category_tags import router as category_tags
from routes.route_favorites import router as favorites
from routes.route_tags import router as tags
from routes.route_templates import router as templates
from routes.route_template_tags import router as template_tags
from routes.route_fetch_all import router as fetch_all
from routes.route_tags_search import router as route_tags_search
from routes.route_tag_templates import router as route_tag_templates

VERSION_NUMBER = '0.0.0'
app = FastAPI(title="FaceSwap-AI", version=VERSION_NUMBER)


# Define the timeout middleware
class TimeoutMiddleware(BaseHTTPMiddleware):
    def __init__(self, app: FastAPI, timeout: int):
        super().__init__(app)
        self.timeout = timeout

    async def dispatch(self, request: Request, call_next):
        try:
            with async_timeout.timeout(self.timeout):
                response = await call_next(request)
                return response
        except Exception as e:
            return JSONResponse(
                content={"detail": "Request timed out"},
                status_code=504
            )

# app.add_middleware(TimeoutMiddleware, timeout=120)


app.include_router(categories)
app.include_router(templates)
app.include_router(favorites)
# app.include_router(tags)
# app.include_router(template_tags)
app.include_router(route_tags_search)
app.include_router(route_tag_templates)
app.include_router(fetch_all)



if __name__ == '__main__':
    uvicorn.run(app, host="127.0.0.1", port=8000)
