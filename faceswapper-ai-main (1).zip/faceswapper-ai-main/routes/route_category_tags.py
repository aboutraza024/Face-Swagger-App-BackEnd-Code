from typing import Optional

from starlette.exceptions import HTTPException

from models.model import CategoryTags, Categories, Tags
from schemas.schema_category_tags import CategoryTagsBase, CategoryTagsResponse
from fastapi import Depends, APIRouter
from dependencies.database_depend import get_db
from sqlalchemy.orm import Session

router = APIRouter()


def create_category_tag(db: Session, category_tag: CategoryTagsBase):
    db_category = db.query(Categories).filter(Categories.id == category_tag.category_id).first()
    db_tag = db.query(Tags).filter(Tags.id == category_tag.tag_id).first()

    if not db_category or not db_tag:
        raise HTTPException(status_code=404, detail=f"Category or Tag not found!")

    db_exists = db.query(CategoryTags).filter(CategoryTags.category_id == category_tag.category_id,
                                              CategoryTags.tag_id == category_tag.tag_id).first()

    if db_exists:
        raise HTTPException(status_code=500, detail=f"Category already attached to tag")

    category_tag_data = CategoryTags(category_id=category_tag.category_id, tag_id=category_tag.tag_id)
    db.add(category_tag_data)
    db.commit()
    db.refresh(category_tag_data)
    return category_tag_data


def delete_category_tag(db: Session, category_tag_id: int):
    db_exists = db.query(CategoryTags).filter(CategoryTags.id == category_tag_id).first()

    if not db_exists:
        raise HTTPException(status_code=500, detail=f"Category is not attached to tag")

    db.delete(db_exists)
    db.commit()
    return db_exists


@router.post("/categoryTags/create")
def create(category_tag: CategoryTagsBase, db: Session = Depends(get_db)):
    category_tag = create_category_tag(db=db, category_tag=category_tag)
    return {"success": True, "result": {}}


@router.delete("/categoryTags/delete")
def delete(category_tag_id: int, db: Session = Depends(get_db)):
    del_tuple = delete_category_tag(db=db, category_tag_id=category_tag_id)
    return {"success": True, "result": {}}
