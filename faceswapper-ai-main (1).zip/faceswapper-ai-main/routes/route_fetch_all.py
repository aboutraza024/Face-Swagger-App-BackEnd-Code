from sqlalchemy import func
from starlette.exceptions import HTTPException
from sqlalchemy import asc
from models.model import Tags, Templates, TemplateTags, Favorites, Categories, CategoryTags
from sqlalchemy.orm import Session
from fastapi import FastAPI, Depends, APIRouter, Form
from dependencies.database_depend import get_db

router = APIRouter()


def get_all_category_data(db: Session, user_id: str):
    db_favorites = db.query(Favorites.template_id).filter(Favorites.user_id == user_id).all()
    favorites = [favorite.template_id for favorite in db_favorites]

    db_templates = (db.query(Templates).filter(Templates.category_id == Categories.id,
                                               Templates.status == 1).order_by(asc(Templates.position)).all())
    templates = []
    for template in db_templates:
        template_dict = {
            "id": template.id,
            "category_id": template.category_id,
            "status": template.status,
            "position": template.position,
            "is_premium": template.is_premium,
            "low_quality_image_url": template.low_quality_image_url,
            "original_image_url": template.original_image_url,
            "is_favorite": template.id in favorites if favorites else False
        }
        templates.append(template_dict)
    print(templates)
    category_dict = {
        "name": "all",
        "templates": templates,
    }

    return category_dict


def get_category_data(db: Session, db_category, user_id: str):
    db_favorites = db.query(Favorites.template_id).filter(Favorites.user_id == user_id).all()
    favorites = [favorite.template_id for favorite in db_favorites]

    db_templates = (db.query(Templates).filter(Templates.category_id == db_category.id,
                                               Templates.status == 1).all())
    templates = []
    for template in db_templates:
        template_dict = {
            "id": template.id,
            "category_id": template.category_id,
            "status": template.status,
            "position": template.position,
            "is_premium": template.is_premium,
            "low_quality_image_url": template.low_quality_image_url,
            "original_image_url": template.original_image_url,
            "is_favorite": template.id in favorites if favorites else False
        }
        templates.append(template_dict)

    category_dict = {
        "id": db_category.id,
        "name": db_category.name,
        "templates": templates,
    }

    return category_dict


def get_tags_with_template_counts(db: Session):
    tags_with_counts = (
        db.query(Tags.id, Tags.name, func.count(Templates.id).label("template_count"))
        .join(TemplateTags, Tags.id == TemplateTags.tag_id)
        .join(Templates, Templates.id == TemplateTags.template_id)
        .group_by(Tags.id)
        .having(func.count(Templates.id) > 0)
        .all()
    )

    result = [{"id": tag_id, "name": tag_name, "template_count": template_count} for tag_id, tag_name, template_count in
              tags_with_counts]

    return result


@router.post("/fetch-all1")
def fetch_all(
        user_id: str = Form(...),
        db: Session = Depends(get_db)):
    result1 = {}
    result = {}
    category_names = []
    categories = []
    db_categories = db.query(Categories).order_by(Categories.position).where(Categories.status == 1).all()
    tags = get_tags_with_template_counts(db)
    for db_category in db_categories:
        category = get_category_data(db, db_category, user_id)
        if len(category['templates']) > 0:
            category_names.append(category['name'])
            # is sa pahla all to daalna ha
            categories.append(category)

    result['names'] = category_names
    result['tags'] = tags
    all = get_all_category_data(db, user_id)
    categories.insert(0, all)
    result['categories'] = categories

    return {"success": True, "result": result}
