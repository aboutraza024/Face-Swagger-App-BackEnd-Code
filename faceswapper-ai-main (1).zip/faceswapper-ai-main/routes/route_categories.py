from typing import Optional

from starlette.responses import JSONResponse

from models.model import Categories
from schemas.schema_categories import CategoryBase, CategoryResponse
from fastapi import Depends, APIRouter, HTTPException

from dependencies.database_depend import get_db
from sqlalchemy.orm import Session

router = APIRouter()


async def create_category(db: Session, category: CategoryBase):
    category_data = Categories(name=category.name, status=category.status, position=category.position)

    category_exists = db.query(Categories).filter(Categories.name == category.name).first()

    # anything is returned
    if category_exists:
        raise HTTPException(status_code=500, detail=f"Category with same name already exists")

    db.add(category_data)
    db.commit()
    db.refresh(category_data)
    return category_data


def fetch_all_categories(db: Session):
    categories = db.query(Categories).order_by(Categories.position).where(Categories.status == 1).all()

    category_list = [
        {
            "id": category.id,
            "name": category.name,
            "position": category.position,
            "status": category.status
        }
        for category in categories
    ]
    return category_list


async def delete_category(db: Session, category_id: int):
    category = db.query(Categories).filter(Categories.id == category_id).first()
    if not category:
        raise HTTPException(status_code=404, detail=f"Category not found!")

    db.delete(category)
    db.commit()
    return {"success": True, "result": {}}


async def update_category(db: Session, category_id: int, category: CategoryBase):
    db_category = db.query(Categories).filter(Categories.id == category_id).first()

    if not db_category:
        raise HTTPException(status_code=404, detail=f"Category not found!")

    if category.name and category.name != db_category.name:

        category_exists = db.query(Categories).where(Categories.name == category.name).first()
        if category_exists:
            raise HTTPException(status_code=500, detail=f"Category with same name already exists")

        db_category.name = category.name

    if category.position:
        db_category.position = category.position
    if category.status:
        db_category.status = category.status

    db.commit()
    db.refresh(db_category)
    return {"success": True, "result": {}}


@router.post("/categories/create", response_model=CategoryResponse)
async def create(category: CategoryBase, db: Session = Depends(get_db)):
    return await create_category(db=db, category=category)


# @router.post("/categories/fetch/all")
async def fetch_all(db: Session = Depends(get_db)):
    categories = fetch_all_categories(db=db)
    return {"success": True, "result": categories}


@router.patch("/categories/update", description="update category - endpoint")
async def update(category_id: int, category: CategoryBase, db: Session = Depends(get_db)):
    updated_row = await update_category(db=db, category_id=category_id, category=category)
    return {"success": True, "result": updated_row}


# @router.delete("/categories/delete")
async def delete(category_id: int, db: Session = Depends(get_db)):
    del_tuple = await delete_category(db=db, category_id=category_id)
    return {"success": True, "result": {}}
