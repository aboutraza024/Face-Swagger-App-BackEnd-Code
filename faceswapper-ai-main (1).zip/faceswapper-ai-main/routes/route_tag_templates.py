from sqlalchemy import func
from starlette.exceptions import HTTPException

from models.model import Tags, Templates, TemplateTags, Favorites, Categories
from sqlalchemy.orm import Session
from fastapi import FastAPI, Depends, APIRouter, Form
from dependencies.database_depend import get_db

router = APIRouter()


def tag_templates(db: Session, tag_id: int, user_id: str):
    # Query to get the tag by ID
    db_tag = (
        db.query(Tags.id, Tags.name)
        .filter(Tags.id == tag_id)
        .first()
    )

    if not db_tag:
        raise HTTPException(status_code=404, detail=f"Tag not found!")

    db_favorites = db.query(Favorites.template_id).filter(Favorites.user_id == user_id).all()
    favorites = {favorite.template_id for favorite in db_favorites}

    templates = (
        db.query(Templates)
        .join(TemplateTags, Templates.id == TemplateTags.template_id)
        .join(Categories, Categories.id == Templates.category_id)
        .filter(
            TemplateTags.tag_id == tag_id,
            Templates.status == 1,
            Categories.status == 1
        )
        .order_by(Templates.position)
        .all()
    )

    # Prepare the list of templates with favorite status
    all_templates = [
        {
            "id": t.id,
            "name": t.name,
            "status": t.status,
            "position": t.position,
            "is_premium": t.is_premium,
            "low_quality_image_url": t.low_quality_image_url,
            "original_image_url": t.original_image_url,
            "is_favorite": t.id in favorites
        }
        for t in templates
    ]

    # Prepare the final result
    result = {
        "id": db_tag.id,
        "name": db_tag.name,
        "templates": all_templates
    }

    return result


@router.post("/tags/templates")
def fetch_tag_templates(tag_id: int = Form(...), user_id: str = Form(...), db: Session = Depends(get_db)):
    tags = tag_templates(db=db, tag_id=tag_id, user_id=user_id)
    return {"success": True, "result": tags}
