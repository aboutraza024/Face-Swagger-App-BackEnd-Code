from sqlalchemy import func
from models.model import Tags, Templates, TemplateTags
from sqlalchemy.orm import Session
from fastapi import FastAPI, Depends, APIRouter, Form
from dependencies.database_depend import get_db
router = APIRouter()


def search_tags(db: Session, tag: str):
    tags_with_counts = (
        db.query(Tags.id, Tags.name, func.count(Templates.id).label("template_count"))
        .join(TemplateTags, Tags.id == TemplateTags.tag_id)
        .join(Templates, Templates.id == TemplateTags.template_id)
        .group_by(Tags.id)
        .having(func.count(Templates.id) > 0)
        .filter(Tags.name.like(f"%{tag}%"))
        .all()
    )

    tags_list = [{"id": tag_id, "name": tag_name, "template_count": template_count} for tag_id, tag_name, template_count
                 in
                 tags_with_counts]

    return tags_list


@router.post("/tags/search")
def search(tag: str = Form(...), db: Session = Depends(get_db)):
    tags = search_tags(db=db, tag=tag)
    return {"success": True, "result": tags}
