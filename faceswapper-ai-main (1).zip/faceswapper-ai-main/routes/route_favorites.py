from starlette.exceptions import HTTPException
from models.model import Favorites
from schemas.schema_favorites import FavoriteResponse, FavoriteBase
from sqlalchemy.orm import Session
from fastapi import FastAPI, Depends, APIRouter
from dependencies.database_depend import get_db
from typing import Optional
router = APIRouter()


def add_favorite(db: Session, favorite: FavoriteBase):
    favorite_data = Favorites(user_id=favorite.user_id, template_id=favorite.template_id)
    favorite_exists = db.query(Favorites).where(
        Favorites.user_id == favorite.user_id).where(Favorites.template_id == favorite.template_id).first()

    if favorite_exists:
        raise HTTPException(status_code=200, detail=f"Template already in favorites")

    db.add(favorite_data)
    db.commit()
    db.refresh(favorite_data)
    return favorite_data


def fetch_user_favorites(db: Session, user_id: str):
    favorites = db.query(Favorites).filter(Favorites.user_id == user_id).all()
    return favorites


def favorite_remove(db: Session, user_id: str, favorites_id: int):
    favorite = db.query(Favorites).filter(Favorites.user_id == user_id, Favorites.id == favorites_id).first()

    if not favorite:
        raise HTTPException(status_code=404, detail=f"Favorite not found!")

    db.delete(favorite)
    db.commit()
    return favorite


@router.post("/favorites/create", response_model=FavoriteResponse)
def create(favorite: FavoriteBase, db: Session = Depends(get_db)):
    favorite = add_favorite(db=db, favorite=favorite)
    return {'success': True, 'result': {}}


@router.post("/favorites/fetch/all")
def fetch_favorites(user_id: str, db: Session = Depends(get_db)):
    favorites = fetch_user_favorites(db=db, user_id=user_id)
    return {'success': True, 'result': favorites}


@router.delete("/favorites/remove")
def remove_favorite(user_id: str, favorite_id: int, db: Session = Depends(get_db)):
    del_tuple = favorite_remove(db=db, user_id=user_id, favorites_id=favorite_id)
    return {'success': True, 'result': {}}
