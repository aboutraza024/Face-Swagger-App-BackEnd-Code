import asyncio
import os
import uuid
from typing import Optional
from pathlib import Path
import boto3
from fastapi import Depends
from starlette.responses import JSONResponse
from dependencies.database_depend import get_db
from sqlalchemy.orm import Session
from models.model import Templates, Categories
from schemas.schema_templates import TemplateBase, TemplateResponse
from fastapi import FastAPI, Form, UploadFile, File, APIRouter
from fastapi.exceptions import HTTPException
from dotenv import load_dotenv

load_dotenv()
router = APIRouter()

UPLOAD_DIRECTORY = Path(os.getenv('UPLOAD_DIRECTORY'))
UPLOAD_DIRECTORY.mkdir(parents=True, exist_ok=True)
ALLOWED_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.webp'}
s3_client = boto3.client(
    's3',
    aws_access_key_id=os.getenv('aws_access_key_id'),
    aws_secret_access_key=os.getenv('aws_secret_access_key'),
    region_name=os.getenv('region_name')
)


def allowed_extension(filename: str) -> bool:
    return any(filename.lower().endswith(ext) for ext in ALLOWED_EXTENSIONS)


def insert_templates(db: Session, template: TemplateBase):
    template_data = Templates(name=template.name,
                              status=True,
                              position=50,
                              is_premium=False,
                              category_id=template.category_id,
                              original_image_url=template.original_image_url,
                              low_quality_image_url=template.low_quality_image_url
                              )
    db.add(template_data)
    db.commit()
    db.refresh(template_data)
    return template_data


def fetch_by_id(db: Session, template_id: int):
    template = db.query(Templates).filter(Templates.id == template_id).first()
    if not template:
        raise HTTPException(status_code=404, detail=f"Template not found!")

    return template


def fetch_all_templates(db: Session):
    templates_list = db.query(Templates).all()
    templates_list = [
        {
            "id": template.id,
            "category_id": template.category_id,
            "position": template.position,
            "status": template.status,
            "is_premium": template.is_premium,
            "low_quality_image_url": template.low_quality_image_url,
            "original_image_url": template.original_image_url,
        }
        for template in templates_list
    ]
    return templates_list


def delete_template(db: Session, template_id: int):
    template = db.query(Templates).filter(Templates.id == template_id).first()
    if not template:
        raise HTTPException(status_code=404, detail=f"Template not found!")

    db.delete(template)
    db.commit()
    return template


def update_template(db: Session, template_id: int, template: TemplateBase):
    db_template = db.query(Templates).filter(Templates.id == template_id).first()
    if not db_template:
        raise HTTPException(status_code=404, detail=f"Template not found!")

    if template.position is not None:
        db_template.position = template.position
    if template.status is not None:
        db_template.status = template.status
    if template.is_premium is not None:
        db_template.is_premium = template.is_premium

    db.commit()
    db.refresh(db_template)
    return db_template


async def upload_to_s3(file_obj, bucket_name, s3_path):
    try:
        await asyncio.to_thread(s3_client.upload_fileobj, file_obj, bucket_name, s3_path)
        return f"{os.getenv('S3_BASE_PATH')}/{s3_path}"
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to upload to S3: {str(e)}")


@router.post("/templates/create")
async def create(category_id: int = Form(...),
                 original_image: UploadFile = File(...),
                 low_image: UploadFile = File(...),
                 db: Session = Depends(get_db)):

    if not allowed_extension(original_image.filename) or not allowed_extension(low_image.filename):
        raise HTTPException(status_code=400, detail="Invalid file type")

    category = db.query(Categories).filter(Categories.id == category_id).first()
    if category is None:
        raise HTTPException(status_code=404, detail="Category not found!")

    random_string = str(uuid.uuid4())[:7]
    bucket_name = os.getenv('S3_BUCKET_NAME')
    original_image_name = os.path.splitext(os.path.basename(original_image.filename))[0]
    low_image_name = os.path.splitext(os.path.basename(low_image.filename))[0]

    # S3 paths for the files
    original_image_s3_path = f"{os.getenv('OUTPUT_PATH')}/{random_string}_{original_image_name}/{random_string}_{original_image.filename}"
    low_image_s3_path = f"{os.getenv('OUTPUT_PATH')}/{random_string}_{low_image_name}/{random_string}_{low_image.filename}"

    # Upload original image to S3
    s3_original_url = await upload_to_s3(original_image.file, bucket_name, original_image_s3_path)
    s3_low_url = await upload_to_s3(low_image.file, bucket_name, low_image_s3_path)

    template = TemplateBase(
        name=random_string,
        status=False,
        position=50,
        is_premium=False,
        category_id=category_id,
        original_image_url=f"{s3_original_url}",
        low_quality_image_url=f"{s3_low_url}"
    )
    status = insert_templates(db=db, template=template)

    return JSONResponse({'success': True, 'result': {}}, 200)


# @router.post("/templates/fetch/all")
def fetch_templates(db: Session = Depends(get_db)):
    templates = fetch_all_templates(db=db)
    return {'success': True, 'result': templates}


@router.patch("/templates/update")
def update(template_id: int,
           status: bool = Form(...),
           is_premium: bool = Form(...),
           position: int = Form(...),
           db: Session = Depends(get_db)):

    template = TemplateBase(name="None",
                            status=status,
                            position=position,
                            is_premium=is_premium,
                            category_id=2,
                            original_image_url="None",
                            low_quality_image_url="None")
    template = update_template(db=db, template_id=template_id, template=template)
    return {'success': True, 'result': template}


@router.delete("/template/delete")
def delete(template_id: Optional[int] = None, db: Session = Depends(get_db)):
    del_tuple = delete_template(db=db, template_id=template_id)
    return {'success': True, 'result': {}}