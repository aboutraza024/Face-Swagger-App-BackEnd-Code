from typing import Optional
from starlette.exceptions import HTTPException
from models.model import TemplateTags, Categories, Tags, Templates
from schemas.schema_template_tags import TemplateTagsBase, TemplateTagsResponse
from fastapi import Depends, APIRouter
from dependencies.database_depend import get_db
from sqlalchemy.orm import Session
router = APIRouter()


def create_template_tag(db: Session, template_tag: TemplateTagsBase):
    db_template = db.query(Templates).filter(Templates.id == template_tag.template_id).first()
    db_tag = db.query(Tags).filter(Tags.id == template_tag.tag_id).first()

    if not db_template or not db_tag:
        raise HTTPException(status_code=404, detail=f"Template or Tag not found!")

    db_exists = db.query(TemplateTags).filter(TemplateTags.template_id == template_tag.template_id,
                                              TemplateTags.tag_id == template_tag.tag_id).first()

    if db_exists:
        raise HTTPException(status_code=500, detail=f"Template already has this tag")

    tem_tag_data = TemplateTags(template_id=template_tag.template_id, tag_id=template_tag.tag_id)
    db.add(tem_tag_data)
    db.commit()
    db.refresh(tem_tag_data)
    return tem_tag_data


def fetch_all(db: Session):
    return db.query(TemplateTags).all()


def detach(db: Session, template_tag_id: int):
    db_exists = db.query(TemplateTags).filter(TemplateTags.id == template_tag_id).first()

    if not db_exists:
        raise HTTPException(status_code=500, detail=f"Template is not attached to tag")

    db.delete(db_exists)
    db.commit()
    return db_exists


@router.post("/template_tags/create")
def attach(template_tag: TemplateTagsBase, db: Session = Depends(get_db)):
    db_tag = create_template_tag(db=db, template_tag=template_tag)
    return {"success": True, "result": {}}


@router.post("/template_tags/fetch/all")
def fetch(db: Session = Depends(get_db)):
    tag = fetch_all(db=db)
    return {"tags table data": tag}


@router.delete("/template_tags/delete_by_id")
def delete(tag_id: int, db: Session = Depends(get_db)):
    del_tuple = detach(db=db, template_tag_id=tag_id)
    return {"Row Deleted SuccessFully": del_tuple}
