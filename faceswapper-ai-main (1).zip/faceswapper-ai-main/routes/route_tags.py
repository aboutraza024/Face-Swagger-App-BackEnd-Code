from starlette.exceptions import HTTPException
from schemas.schema_tags import TagBase, TagResponse
from models.model import Tags
from sqlalchemy.orm import Session
from fastapi import FastAPI, Depends, APIRouter
from dependencies.database_depend import get_db
from typing import Optional

router = APIRouter()


def create_tags(db: Session, tag: TagBase):
    db_tag = db.query(Tags).filter(Tags.name == tag.name).first()
    if db_tag:
        raise HTTPException(status_code=400, detail=f"Tag already exists!")

    tag_data = Tags(name=tag.name)
    db.add(tag_data)
    db.commit()
    db.refresh(tag_data)
    return tag_data


def fetch_all_tags(db: Session):
    tags = db.query(Tags).all()

    tags_list = [
        {
            "id": tag.id,
            "name": tag.name,
            "status": tag.status
        }
        for tag in tags
    ]
    return tags_list


def delete_tag(db: Session, tag_id):
    db_tag = db.query(Tags).filter(Tags.id == tag_id).first()
    if not db_tag:
        raise HTTPException(status_code=404, detail=f"Tag not found!")

    db.delete(db_tag)
    db.commit()
    return db_tag


def update_tag(db: Session, tag_id: int, tag: TagBase):
    db_tag = db.query(Tags).filter(Tags.id == tag_id).first()
    if not db_tag:
        raise HTTPException(status_code=404, detail=f"Tag not found!")

    if tag.name and tag.name != db_tag.name:
        # avoid any tag name duplication exception
        tag_exists = db.query(Tags).where(Tags.name == tag.name).first()
        if tag_exists:
            raise HTTPException(status_code=500, detail=f"Tag with same name already exists")

        db_tag.name = tag.name
    db.commit()
    db.refresh(db_tag)
    return db_tag


@router.post("/tags/create")
def create(tag: TagBase, db: Session = Depends(get_db)):
    tag_data = create_tags(db=db, tag=tag)
    return {"success": True, "result": {}}


@router.post("/tags/fetch/all")
def fetch_all(db: Session = Depends(get_db)):
    tags = fetch_all_tags(db=db)
    return {"success": True, "result": tags}


@router.patch("/tags/update")
def update(tag_id: int, tag: TagBase, db: Session = Depends(get_db)):
    db_tag = update_tag(db=db, tag_id=tag_id, tag=tag)
    return {"success": True, "result": {}}


@router.delete("/tag/delete")
def delete(tag_id: Optional[int] = None, db: Session = Depends(get_db)):
    db_tag = delete_tag(db=db, tag_id=tag_id)
    return {"success": True, "result": {}}
