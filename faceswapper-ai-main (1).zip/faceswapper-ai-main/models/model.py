from sqlalchemy.orm import Session, sessionmaker, relationship, declarative_base
from sqlalchemy import Integer, Float, String, create_engine, Column, ForeignKey, Boolean, DateTime
from sqlalchemy.sql import func
from sqlalchemy.dialects.mysql import TINYINT
from config import Base, engine


class TemplateTags(Base):
    __tablename__ = "templatetags"
    id = Column(Integer, primary_key=True, autoincrement=True)
    template_id = Column(Integer, ForeignKey("templates.id"))
    tag_id = Column(Integer, ForeignKey("tags.id"))


class CategoryTags(Base):
    __tablename__ = "categorytags"
    id = Column(Integer, primary_key=True, autoincrement=True)
    category_id = Column(Integer, ForeignKey("categories.id"))
    tag_id = Column(Integer, ForeignKey("tags.id"))


class Categories(Base):
    __tablename__ = "categories"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), unique=True)
    status = Column(Boolean, default=True)
    position = Column(TINYINT, default=50)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now())

    # templates = relationship("Templates", back_populates="category")

    # tages = relationship("Tags", back_populates="category")
    # tags = relationship("Tags", secondary="categorytags", back_populates="category2")


class Templates(Base):
    __tablename__ = "templates"
    id = Column(Integer, primary_key=True, autoincrement=True)
    category_id = Column(Integer, ForeignKey("categories.id"))  # make it as a foriegn key
    name = Column(String(100), unique=True)
    status = Column(Boolean, default=True)
    position = Column(TINYINT, default=50)
    is_premium = Column(Boolean, default=False)
    original_image_url = Column(String(200))
    low_quality_image_url = Column(String(200))
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now())

    # category = relationship("Categories", back_populates="templates")
    favorites = relationship("Favorites", back_populates="template")
    # tags2 = relationship("Tags", secondary="templatetags", back_populates="template2")


class Favorites(Base):
    __tablename__ = "favorites"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer)
    template_id = Column(Integer, ForeignKey("templates.id"))  # foreign key
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now())

    template = relationship("Templates", back_populates="favorites")


class Tags(Base):
    __tablename__ = "tags"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String(100), unique=True)
    status = Column(Boolean, default=True)
    created_at = Column(DateTime, default=func.now())
    updated_at = Column(DateTime, default=func.now())

    # category2 = relationship("Categories", secondary="categorytags", back_populates="tags")
    # template2 = relationship("Templates", secondary="templatetags", back_populates="tags2")


Base.metadata.create_all(bind=engine)
