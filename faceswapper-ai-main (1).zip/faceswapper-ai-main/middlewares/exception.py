from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware
import logging

logger = logging.getLogger(__name__)

class ExceptionHandlerMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        try:
            return await call_next(request)
        except HTTPException as http_exception:
            return JSONResponse(
                status_code=http_exception.status_code,
                content={"success": False, "message": str(http_exception.detail)},
            )
        except Exception as e:
            logger.exception(msg=str(e))
            return JSONResponse(
                status_code=500,
                content={"success": False, "message": "An unexpected error occurred."},
            )