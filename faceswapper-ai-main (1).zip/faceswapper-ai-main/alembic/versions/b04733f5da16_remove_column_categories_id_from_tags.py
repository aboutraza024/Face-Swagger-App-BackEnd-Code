"""remove column categories id from tags

Revision ID: b04733f5da16
Revises: 7c5e463f40f5
Create Date: 2024-08-31 17:16:05.560704

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'b04733f5da16'
down_revision: Union[str, None] = '7c5e463f40f5'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    pass
    # op.drop_column('tags', 'categories_id')


def downgrade() -> None:
    pass
