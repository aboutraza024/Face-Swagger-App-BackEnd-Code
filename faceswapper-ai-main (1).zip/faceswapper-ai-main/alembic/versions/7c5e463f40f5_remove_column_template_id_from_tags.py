"""remove column template id from tags

Revision ID: 7c5e463f40f5
Revises: 31bee002387b
Create Date: 2024-08-31 17:15:56.350452

"""
from typing import Sequence, Union
from sqlalchemy.exc import OperationalError
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '7c5e463f40f5'
down_revision: Union[str, None] = '31bee002387b'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    try:
        op.drop_column('tags', 'template_id')
    except OperationalError:
        print("An error occurred while adding or modifying the 'status' column.")

def downgrade() -> None:
    pass
