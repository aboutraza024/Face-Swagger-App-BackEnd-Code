"""add tag name column to tags table

Revision ID: 31bee002387b
Revises: da48850adbb7
Create Date: 2024-08-31 17:09:58.365498

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = '31bee002387b'
down_revision: Union[str, None] = 'da48850adbb7'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column('tags', sa.Column('name', sa.String(length=100), unique=True))
    op.execute('ALTER TABLE tags MODIFY COLUMN name VARCHAR(100) UNIQUE AFTER id;')


def downgrade() -> None:
    op.drop_column('tags', 'name')
