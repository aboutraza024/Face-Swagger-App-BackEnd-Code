"""add column status to tags

Revision ID: aa2df8407260
Revises: b04733f5da16
Create Date: 2024-09-01 21:46:41.832528

"""
from typing import Sequence, Union
from sqlalchemy.exc import OperationalError
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'aa2df8407260'
down_revision: Union[str, None] = 'b04733f5da16'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    try:
        # Add the new 'status' column
        op.add_column('tags', sa.Column('status', sa.Boolean, default=True))

        # Modify the column position (MySQL specific command)
        op.execute('ALTER TABLE tags MODIFY COLUMN status BOOLEAN DEFAULT TRUE AFTER name;')
    except OperationalError:
        print("An error occurred while adding or modifying the 'status' column.")


def downgrade() -> None:
    try:
        # Remove the 'status' column if it exists
        op.drop_column('tags', 'status')
    except OperationalError:
        print("An error occurred while dropping the 'status' column.")
