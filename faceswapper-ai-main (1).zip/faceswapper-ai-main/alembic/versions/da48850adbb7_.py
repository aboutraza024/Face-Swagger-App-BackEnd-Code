"""empty message

Revision ID: da48850adbb7
Revises:
Create Date: 2024-08-30 15:54:21.973430

"""
from typing import Sequence, Union
from sqlalchemy.exc import OperationalError
from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import mysql

# revision identifiers, used by Alembic.
revision: str = 'da48850adbb7'
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade():
    try:
        # Rename the column if it exists
        op.alter_column('templates', 'categories_id', new_column_name='category_id', existing_type=sa.Integer)
    except OperationalError:
        print("Column 'categories_id' does not exist or has already been renamed.")


def downgrade():
    try:
        # Revert the column name if the change was applied
        op.alter_column('templates', 'category_id', new_column_name='categories_id', existing_type=sa.Integer)
    except OperationalError:
        print("Column 'category_id' does not exist or has already been reverted.")