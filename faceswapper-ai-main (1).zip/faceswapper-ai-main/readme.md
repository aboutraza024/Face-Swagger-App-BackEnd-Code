# Faceswapper-AI

This project is a FastAPI-based application that uses SQLAlchemy for database operations, along with Alembic for database migrations.

## Requirements

- Python 3.8 or higher
- Git (optional, for version control)

## Installation

### 1. Clone the Repository

First, clone this repository to your local machine:

```bash
git clone https://github.com/yourusername/your-repository-name.git
cd your-repository-name
