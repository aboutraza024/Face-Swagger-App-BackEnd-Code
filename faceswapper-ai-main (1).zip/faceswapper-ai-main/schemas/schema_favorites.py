from pydantic import BaseModel
from datetime import datetime


class FavoriteBase(BaseModel):
    user_id: int
    template_id: int


class FavoriteResponse(BaseModel):
    id: int
    user_id: int
    template_id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        form_attributes: True
