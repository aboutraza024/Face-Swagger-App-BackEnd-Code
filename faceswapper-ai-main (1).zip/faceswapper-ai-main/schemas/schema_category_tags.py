from pydantic import BaseModel


class CategoryTagsBase(BaseModel):
    category_id: int
    tag_id: int


class CategoryTagsResponse(CategoryTagsBase):
    id: int

    class Config:
        form_attributes: True
