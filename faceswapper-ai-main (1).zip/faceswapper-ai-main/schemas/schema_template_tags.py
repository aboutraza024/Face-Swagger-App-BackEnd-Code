from pydantic import BaseModel

class TemplateTagsBase(BaseModel):
    template_id: int
    tag_id: int


class TemplateTagsResponse(TemplateTagsBase):
    id: int

    class Config:
        form_attributes: True
