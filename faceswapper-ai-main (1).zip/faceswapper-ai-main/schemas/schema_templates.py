
from typing import Union,List
from pydantic import BaseModel
from datetime import datetime
from schemas.schema_favorites import FavoriteResponse
from schemas.schema_tags import TagResponse


class TemplateBase(BaseModel):
    name: str
    status: Union[bool, None] = True
    position: Union[int, None] = 50
    is_premium: Union[bool, None] = False
    category_id: int
    original_image_url: str
    low_quality_image_url: str


class TemplateResponse(TemplateBase):
    id: int
    # created_at: datetime
    # updated_at: datetime
    favorites: List[FavoriteResponse] = []
    template: List[TagResponse] = []

    class Config:
        form_attributes: True

