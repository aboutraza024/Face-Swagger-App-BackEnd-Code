from pydantic import BaseModel
from typing import Union, List
from datetime import datetime
from schemas.schema_tags import TagResponse
from schemas.schema_templates import TemplateResponse


class CategoryBase(BaseModel):
    name: str
    status: Union[bool, None] = True
    position: Union[int, None] = 50


class CategoryResponse(CategoryBase):
    id: int
    created_at: datetime
    updated_at: datetime
    # templates: List[TemplateResponse] = []
    Category: List[TagResponse] = []

    class Config:
        form_attributes: True
