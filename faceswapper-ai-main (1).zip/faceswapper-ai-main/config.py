import os

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker,declarative_base
from dotenv import load_dotenv

load_dotenv()

SQL_ALCHEMY_DATABASE_URL = f"{os.getenv('SQL_ALCHEMY_DATABASE_URL')}"  # move this to .env file
engine = create_engine(SQL_ALCHEMY_DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()



